### Milesttone1:
6. user info edit chnages. -working... --done
5. homepage area selection to multiple-choice and the first item to "All" advance filter. ... working --done
1. Admin panel: fixes, --worjing not Found the component.
2. music share fixes. --working   --- Done if song file is available then will play else it opens the dialog
3. music box ui chnage  --- Done.
4. Authorization logic -> without signing in user cannot do mentioned functions. -- working. Done 
7. profile drop-down options should work.   --done edit works. Done.
8. musician page ui done in hiring.
