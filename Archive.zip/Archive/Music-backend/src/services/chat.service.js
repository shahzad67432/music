const Chat = require('../models/chat.model'); // Import the Chat model
const mongoose = require('mongoose');

/**
 * Chat Service: Handles chat-related business logic.
 */
const ChatService = {

    /**
   * Get chat history between two users.
   *
   * @param {string} currentUserId - ID of the logged-in user.
   * @param {string} userId - ID of the other user in the chat.
   * @returns {Promise<Object>} - Chat document containing messages.
   */
  async getChatHistory(currentUserId, userId) {
    try {
      const chat = await Chat.findOne({
        participants: { $all: [currentUserId, userId] },
      }).select('messages');
      return chat;
    } catch (error) {
      console.error('Error fetching chat history:', error);
      throw new Error('Unable to fetch chat history.');
    }
  },

  /**
   * Save a message in the chat between two participants.
   * Creates a new chat if it doesn't exist.
   *
   * @param {string} senderId - ID of the sender.
   * @param {string} recipientId - ID of the recipient.
   * @param {string} message - Message text.
   * @returns {Promise<Object>} - Updated chat document.
   */
  async saveMessage(senderId, recipientId, message) {
    try {
      // Convert sender and recipient IDs to ObjectId
      const senderObjectId = new mongoose.Types.ObjectId(senderId);
      const recipientObjectId = new mongoose.Types.ObjectId(recipientId);
  
      // Sort participants to ensure consistency
      const sortedParticipants = [senderObjectId, recipientObjectId].sort();
      console.log('Sorted Participants:', sortedParticipants);

      // Attempt to find the chat
      let chat = await Chat.findOne({ participants: { $all: sortedParticipants } });
  
      if (!chat) {
        // If no chat exists, create one
        chat = new Chat({
          participants: sortedParticipants,
          messages: [{
            sender: senderObjectId,
            text: message,
            createdAt: new Date(),
          }],
        });
      } else {
        // If chat exists, add the new message
        chat.messages.push({
          sender: senderObjectId,
          text: message,
          createdAt: new Date(),
        });
      }
  
      // Save the chat (whether new or updated)
      await chat.save();
  
      return chat;
    } catch (error) {
      console.error('Error saving message:', error);
      throw new Error('Unable to save message.');
    }
  },
   
  
  /**
   * Block a user in a chat.
   *
   * @param {string} userId - ID of the user performing the block.
   * @param {string} blockedUserId - ID of the user to be blocked.
   * @returns {Promise<void>}
   */
  async blockUser(userId, blockedUserId) {
    try {
      await Chat.updateMany(
        { participants: { $all: [userId, blockedUserId] } },
        { $addToSet: { blockedBy: userId } } // Add the blocking user to the `blockedBy` array
      );
    } catch (error) {
      console.error('Error blocking user:', error);
      throw new Error('Unable to block user.');
    }
  },

  /**
   * Report a user in a chat.
   *
   * @param {string} userId - ID of the user reporting.
   * @param {string} reportedUserId - ID of the user being reported.
   * @returns {Promise<void>}
   */
  async reportUser(userId, reportedUserId) {
    try {
      await Chat.updateMany(
        { participants: { $all: [userId, reportedUserId] } },
        { $addToSet: { reportedBy: userId } } // Add the reporting user to the `reportedBy` array
      );
    } catch (error) {
      console.error('Error reporting user:', error);
      throw new Error('Unable to report user.');
    }
  },

  /**
   * Mark all messages as read in a chat for a user.
   *
   * @param {string} chatId - ID of the chat.
   * @param {string} userId - ID of the user marking messages as read.
   * @returns {Promise<void>}
   */
  async markMessagesAsRead(chatId, userId) {
    try {
      const chat = await Chat.findById(chatId);
      if (!chat) {
        throw new Error('Chat not found.');
      }

      chat.messages.forEach((message) => {
        if (message.sender !== userId && !message.read) {
          message.read = true; // Mark the message as read
        }
      });

      await chat.save();
    } catch (error) {
      console.error('Error marking messages as read:', error);
      throw new Error('Unable to mark messages as read.');
    }
  },
};

module.exports = ChatService;
