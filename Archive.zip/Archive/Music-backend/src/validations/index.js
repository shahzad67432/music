module.exports.authValidation = require('./auth.validation');
module.exports.userValidation = require('./user.validation');
module.exports.musicValidation = require('./music.validation');
module.exports.userSpaceValidation = require('./userSpace.validation');
module.exports.jobValidation = require('./job.validation');
module.exports.shareMusicValidation = require('./shareMusic.validation');
