const httpStatus = require('http-status');
const pick = require('../utils/pick');
const regexFilter = require('../utils/regexFilter');
const ApiError = require('../utils/ApiError');
const catchAsync = require('../utils/catchAsync');
const { jobService, musicService } = require('../services');
//const upload = require('../config/multer');  

const postJob = catchAsync(async (req, res) => {

  console.log('Req.body in application post job:', req.body);
  const avatarPath = req.body.applicantAvatar || null;
  const backgroundImagePath = req.body.applicantBackgroundImage || null;

  const createdBy = req.user.id;

  // Prepare payload for job creation
  const payload = {
    ...req.body,
    createdBy,
    avatar: avatarPath,
    backgroundImage: backgroundImagePath,
  };

  const job = await jobService.postJob(payload);
  res.status(httpStatus.CREATED).send(job);
});

const getJobs = catchAsync(async (req, res) => {
  const likeFilter = regexFilter(req.query, ['projectTitle']);
  const pickFilter = pick(req.query, ['preferredLocation', 'category']);

  const categoryFilter = Array.isArray(pickFilter.category) ? pickFilter.category : [];

  const filter = {
    ...likeFilter,
    ...pickFilter,
    category: categoryFilter.length > 0 ? { $in: categoryFilter } : undefined,
  };

  const options = pick(req.query, ['sortBy', 'limit', 'page']);
  const result = await jobService.queryJobs(filter, options);
  res.send(result);
});


const getJobById = catchAsync(async (req, res) => {
  const job = await jobService.getJobById(req.params.jobId);
  if (!job) {
    throw new ApiError(httpStatus.NOT_FOUND, 'Job not found');
  }
  res.send(job);
});

const applyJob = catchAsync(async (req, res) => {
  const payload = {
    ...req.body,
    jobId: req.params.jobId,
    createdBy: req.user.id,
  };
  for (const musicId of payload.musicIds) {
    let music = await musicService.getMusicById(musicId);
    if (!music) {
      throw new ApiError(httpStatus.NOT_FOUND, 'There is some Music that cannot be found');
    }
  }
  const appliedJob = await jobService.applyJob(payload);
  res.status(httpStatus.CREATED).send(appliedJob);
});

const deleteJob = catchAsync(async (req, res) => {
  const { jobId } = req.params;
  const job = await jobService.getJobById(jobId);

  if (!job) {
    throw new ApiError(httpStatus.NOT_FOUND, 'Job not found');
  }

  if (job.createdBy.toString() !== req.user.id) {
    throw new ApiError(httpStatus.FORBIDDEN, 'You do not have permission to delete this job');
  }

  // Delete the job
  await jobService.deleteJob(jobId);

  res.status(httpStatus.OK).send({ message: 'Job deleted successfully' });
});

const updateJob = catchAsync(async (req, res) => {
  const { jobId } = req.params;
  const updateData = req.body;

  const job = await jobService.getJobById(jobId);

  if (!job) {
    throw new ApiError(httpStatus.NOT_FOUND, 'Job not found');
  }

  if (job.createdBy.toString() !== req.user.id) {
    throw new ApiError(httpStatus.FORBIDDEN, 'You do not have permission to update this job');
  }

  // Update the job
  const updatedJob = await jobService.updateJob(jobId, updateData);

  res.status(httpStatus.OK).send({ message: 'Job updated successfully', job: updatedJob });
});

module.exports = {
  postJob,
  getJobs,
  getJobById,
  applyJob,
  deleteJob,
  updateJob
};
