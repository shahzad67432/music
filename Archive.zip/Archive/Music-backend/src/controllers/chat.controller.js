const ChatService = require('../services/chat.service'); // Import ChatService

const getChatHistory = async (req, res) => {
  const { userId } = req.params; // ID of the other user in the chat
  const { currentUserId } = req.query; // ID of the current logged-in user

  try {
    const chat = await ChatService.getChatHistory(currentUserId, userId); // Use ChatService

    if (!chat) {
      return res.status(404).json({ success: false, message: 'No chat history found' });
    }

    res.status(200).json({ success: true, data: chat.messages });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
};

const blockUser = async (req, res) => {
  const { userId, blockedUserId } = req.body;

  try {
    await ChatService.blockUser(userId, blockedUserId); // Use ChatService to block user
    res.status(200).send({ success: true, message: 'User blocked successfully.' });
  } catch (error) {
    res.status(500).send({ success: false, message: 'Failed to block user.', error: error.message });
  }
};

const reportUser = async (req, res) => {
  const { userId, reportedUserId } = req.body;

  try {
    await ChatService.reportUser(userId, reportedUserId); // Use ChatService to report user
    res.status(200).send({ success: true, message: 'User reported successfully.' });
  } catch (error) {
    res.status(500).send({ success: false, message: 'Failed to report user.', error: error.message });
  }
};

module.exports = {
  getChatHistory,
  blockUser,
  reportUser,
};
