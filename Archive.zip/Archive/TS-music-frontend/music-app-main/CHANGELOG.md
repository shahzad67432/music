# Change Log

## [1.0.0] 2023-11-21

### Original Release
