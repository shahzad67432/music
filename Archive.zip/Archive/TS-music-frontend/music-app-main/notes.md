offer request dialog
    - need action
    - after action

order info dialog
    - space for upload works

on status revising and delivering
ongoing transaction dialog
    - need action to
        - cancel 
        - complete (on complete theres a confirmation action) -> another dialog to rating and tips
        - need revision (need dialog to give description revision)
        - submit

on status done
finished order dialog

order info dialog for pembeli untuk melihat status selama pekerjaan berlangsung

jika ingin cancel pembeli click cancel, dan penjual akan ada confimation cancel juga
after keduanya setuju, akan ada box untuk summary problem