export const users = [
  {
    id: 1,
    avatar: "https://docs.material-tailwind.com/img/face-2.jpg",
    userName: "Tono",
    creationOccupation: "Composer",
    businessOccupation: "Music Production",
  },
  {
    id: 2,
    avatar: "https://docs.material-tailwind.com/img/face-1.jpg",
    userName: "Bob",
    creationOccupation: "Songwriter",
    businessOccupation: "Music Publishing",
  },
  {
    id: 3,
    avatar: "https://docs.material-tailwind.com/img/face-3.jpg",
    userName: "Charlie",
    creationOccupation: "Composer",
    businessOccupation: "Film Scoring",
  },
  {
    id: 4,
    avatar: "https://docs.material-tailwind.com/img/face-4.jpg",
    userName: "Dana",
    creationOccupation: "Sound Engineer",
    businessOccupation: "Audio Production",
  },
  {
    id: 5,
    avatar: "https://docs.material-tailwind.com/img/face-5.jpg",
    userName: "Eve",
    creationOccupation: "Artist",
    businessOccupation: "Music Performance",
  },
];
