export const dataChat = [
  {
    id: 1,
    avatar: "https://docs.material-tailwind.com/img/face-2.jpg",
    userName: "Alice",
    latestMessages: "Hey, are we still on for tomorrow?",
    unreadChat: 2,
  },
  {
    id: 2,
    avatar: "https://docs.material-tailwind.com/img/face-1.jpg",
    userName: "Bob",
    latestMessages: "Check out this new project idea!",
    unreadChat: 0,
  },
  {
    id: 3,
    avatar: "https://docs.material-tailwind.com/img/face-3.jpg",
    userName: "Charlie",
    latestMessages: "Can you help me?",
    unreadChat: 5,
  },
];
