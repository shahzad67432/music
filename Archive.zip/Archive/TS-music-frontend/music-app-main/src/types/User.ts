export interface User {
  id: string;
  name: string;
  email: string;
  profilPicture: string;
  role: string;
  isEmailVerified: boolean;
}
