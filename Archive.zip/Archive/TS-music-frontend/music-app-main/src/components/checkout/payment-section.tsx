import React from "react";

function PaymentSection() {
  return <div>PaymentSection</div>;
}

export default PaymentSection;
