"use client"

import * as React from "react"
import { Play, Pause, ThumbsUp } from 'lucide-react'
import { useDispatch } from "react-redux"
import { AppDispatch } from "@/redux/store"
import {
  musicPlayerDialog,
  setMusicCreationId,
} from "@/redux/features/offer/offerSlice"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/Avatar"
import { Card, CardContent } from "@/components/ui/Card"
import { Badge } from "@/components/ui/Badge"

interface HomeMusicianBoxProps {
  id: string
  imgSong: string
  songName: string
  singerName: string
  composerName: string
  musicStyle: string
  tags: string[]
  duration?: string
  likes?: number
  audioSrc?: string
}

export function HomeMusicianBox({
  id,
  imgSong,
  songName,
  singerName,
  composerName,
  musicStyle,
  tags,
  duration = "03:45",
  likes = 55,
  audioSrc,
}: HomeMusicianBoxProps) {
  const dispatch = useDispatch<AppDispatch>()
  const [isPlaying, setIsPlaying] = React.useState(false)
  const audioRef = React.useRef<HTMLAudioElement | null>(null)

  const togglePlay = () => {
    if (audioSrc) {
      if (isPlaying) {
        audioRef.current?.pause()
      } else {
        audioRef.current?.play()
      }
      setIsPlaying(!isPlaying)
    } else {
      console.log("Clicked on home music box, ID:", id)
      dispatch(setMusicCreationId(id))
      dispatch(musicPlayerDialog())
    }
  }

  React.useEffect(() => {
    if (audioSrc) {
      audioRef.current = new Audio(audioSrc)
      audioRef.current.addEventListener('ended', () => setIsPlaying(false))
    }

    return () => {
      if (audioRef.current) {
        audioRef.current.pause()
        audioRef.current.removeEventListener('ended', () => setIsPlaying(false))
      }
    }
  }, [audioSrc])

  return (
    <Card className="w-full max-w-2xl hover:shadow-lg transition-shadow duration-200">
      <CardContent className="p-4 space-y-4">
        {/* Top Section: Song Info */}
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-4">
            {/* Album Art */}
            <div className="relative w-16 h-16 rounded-md overflow-hidden bg-muted">
              <img
                src={imgSong || "/image/default-picture.jpg"}
                alt={songName}
                className="object-cover w-full h-full"
                onError={(e: React.SyntheticEvent<HTMLImageElement>) => {
                  e.currentTarget.src = "/image/default-picture.jpg"
                }}
              />
            </div>

            {/* Song Details */}
            <div className="space-y-1">
              <h3 className="font-semibold text-lg leading-none">{songName}</h3>
              <p className="text-sm text-muted-foreground">
                {singerName}
                <span className="text-xs text-muted-foreground"> • Singer</span>
              </p>
            </div>
          </div>

          {/* Play Button and Duration */}
          <div className="flex items-center gap-4">
            <button
              onClick={togglePlay}
              className="rounded-full p-2 hover:bg-muted transition-colors"
              aria-label={isPlaying ? "Pause" : "Play"}
            >
              {isPlaying ? (
                <Pause className="w-6 h-6" />
              ) : (
                <Play className="w-6 h-6" />
              )}
            </button>
            <span className="text-sm text-muted-foreground">{duration}</span>
          </div>
        </div>

        {/* Tags Section */}
        <div className="flex flex-wrap gap-2">
          {Array.isArray(tags) &&
            tags.map((tag, index) => (
              <Badge key={index} variant="secondary">
                {tag}
              </Badge>
            ))}
        </div>

        {/* Bottom Section: Composer Info and Likes */}
        <div className="flex items-center justify-between pt-2 border-t">
          <div className="flex items-center gap-3">
            <Avatar className="w-8 h-8">
              <AvatarImage src="/image/default-picture.jpg" />
              <AvatarFallback>CC</AvatarFallback>
            </Avatar>
            <div className="space-y-1">
              <p className="text-sm font-medium leading-none">{composerName}</p>
              <p className="text-xs text-muted-foreground">
                Composer, Lyricist, Arranger
              </p>
            </div>
          </div>
          <div className="flex items-center gap-1">
            <ThumbsUp className="w-4 h-4 text-muted-foreground" />
            <span className="text-sm text-muted-foreground">{likes}</span>
          </div>
        </div>
      </CardContent>
    </Card>
  )
}

export default HomeMusicianBox

