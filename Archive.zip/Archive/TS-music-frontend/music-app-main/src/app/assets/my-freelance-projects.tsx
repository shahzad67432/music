import React from "react";

function MyFreelanceProjects() {
  return <div>MyFreelanceProjects</div>;
}

export default MyFreelanceProjects;
