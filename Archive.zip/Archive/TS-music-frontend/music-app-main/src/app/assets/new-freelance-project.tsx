import React from "react";

function NewFreelanceProject() {
  return <div>NewFreelanceProject</div>;
}

export default NewFreelanceProject;
