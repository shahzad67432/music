// sections
import RegisterPage from "@/app/auth/register/register-page";

export default function Register() {
  return (
    <>
      <RegisterPage />
    </>
  );
}
