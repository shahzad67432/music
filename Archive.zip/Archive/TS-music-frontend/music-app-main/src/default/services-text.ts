export const FREE_TEXT = [
  "Publish Music works",
  "Offer freelance services",
  "Mark yourself as being available for work",
  "Access to our freelance board",
  "Sell your music assets",
  "Can receive funding from other users with platform fees",
  "Post a recruitment post",
];

export const PRO_TEXT = [
  "Publish Music works",
  "Post recruitment posts",
  "Offer freelance services",
  "Mark yourself as being available for work",
  "Access to our freelance board",
  "Sell your music assets",
  "Reduce platform fees for freelance projects and asset sales by half",
  "Professional badge",
  "Longer personal and music work descriptions",
  "Priority recommendation of your music works",
  "Can receive funding from other users with half platform fees",
  "Priority recommendation for job postings",
  "Prioritize recommending your music asset sales",
  "Free upload of music background",
];
