export const NAV_MENU = [
  // {
  //   name: "Explore",
  //   url: "/",
  // },
  {
    name: "Jobs",
    url: "/jobs",
  },
  // {
  //   name: "My Projects",
  //   url: "/my-projects",
  // },
  {
    name: "Assets",
    url: "/assets",
    title: "find-creatives",
  },
  {
    name: "Go Pro",
    url: "/go-pro",
  },
  {
    name: "Hire Musician",
    url: "/hiring-musician",
    title: "hiring-creatives",
  },
];
